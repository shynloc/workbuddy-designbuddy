"""DesignBuddy core. Standard library only."""
