# 变更记录 · Alpha Demo

> 由 DesignBuddy 0.1.0 从 Brand IR 生成（Design System 1.0.0）。

- 1.0.0：初始版本
