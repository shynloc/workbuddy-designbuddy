# 字体与素材许可 · Alpha Demo

> 由 DesignBuddy 0.1.0 从 Brand IR 生成（Design System 1.0.0）。

| 字体 | 许可 | 可再分发 | 是否随包分发 |
|---|---|---|---|
| Source Han Sans SC | SIL OFL 1.1 | 是 | 否 |
| Source Han Sans SC | SIL OFL 1.1 | 是 | 否 |

| 资产 | 类型 | 许可 | 是否随包分发 |
|---|---|---|---|
| logo-main | logo | user-owned | 是 |
| pattern-3p | pattern | unknown | 否 |

字体文件不随本 Skill 分发。
