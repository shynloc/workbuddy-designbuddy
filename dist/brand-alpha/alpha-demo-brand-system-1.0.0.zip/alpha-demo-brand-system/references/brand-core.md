# 品牌核心 · Alpha Demo

> 由 DesignBuddy 0.1.0 从 Brand IR 生成（Design System 1.0.0）。

| 项 | 内容 |
|---|---|
| 品牌 | Alpha Demo |
| 中文名 | 阿尔法示例 |
| 英文名 | Alpha Demo |
| 别名 | Alpha Demo、阿尔法示例、Alpha、阿尔法 |
| 行业 | 企业软件（虚构） |
| 受众 | 中小企业的运营与财务负责人 |
| 定位 | 让中小企业的数据决策更简单、更可靠 |
| 性格 | 冷静、精确、可靠 |
| 价值观 | 透明、效率 |
| 不想要的感觉 | 浮夸、卡通 |
| 视觉方向 | 沉静专业（Quiet Professional） |

## 关键规则

- `MUST-COLOR-01` **MUST** 主色固定为 #1F4FD8（color.primary）
- `MUST-TYPE-01` **MUST** 所有一级标题使用 Source Han Sans SC，字重 700
- `MUST-TYPE-02` **MUST** 正文使用 Source Han Sans SC；不可用时按回退栈替换
- `MUST-A11Y-01` **MUST** 正文文字与背景对比度不低于 4.5:1，大字号不低于 3:1
- `NEVER-LOGO-01` **NEVER** 不得拉伸、旋转、变色 Logo，不得为 Logo 添加阴影或描边
- `NEVER-COLOR-01` **NEVER** 不得使用色板以外的颜色（照片与插画内容除外）
- `NEVER-PHOTO-01` **NEVER** 不得使用带水印的图库图片
