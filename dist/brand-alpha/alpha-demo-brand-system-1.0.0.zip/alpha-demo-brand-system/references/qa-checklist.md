# Brand QA · Alpha Demo

> 由 DesignBuddy 0.1.0 从 Brand IR 生成（Design System 1.0.0）。

- [ ] Logo：没有违反 NEVER-LOGO-01，安全区与最小尺寸正确
- [ ] 颜色：只使用 color.md 中的颜色；主色用法符合 MUST-COLOR-01
- [ ] 字体：标题和正文字体与字重正确；缺字体时已使用回退栈并说明
- [ ] 间距与对齐：使用 spacing 刻度，元素对齐到栅格
- [ ] 构图：层级清晰，每页或每屏一个核心信息
- [ ] 无障碍：文字对比度满足 accessibility.md
- [ ] 图片风格：符合 imagery.md
- [ ] 语气：只在用户要求时改写内容，并遵守 voice.md
- [ ] 禁止项：没有触发任何 NEVER 规则
