# Excel · Alpha Demo

> 由 DesignBuddy 0.1.0 从 Brand IR 生成（Design System 1.0.0）。

- Excel：表头填充 color.primary + color.on-primary 文字；数据行交替使用 color.paper / color.surface
- 数字右对齐，千分位；负数用 color.error
