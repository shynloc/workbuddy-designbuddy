# 图标 · Alpha Demo

> 由 DesignBuddy 0.1.0 从 Brand IR 生成（Design System 1.0.0）。

- 1.5px 线性图标，圆角端点
- 图标颜色只使用 color.ink、color.primary、color.on-primary。
