# 网页 · Beta Demo

> 由 DesignBuddy 0.1.2 从 Brand IR 生成（Design System 1.0.0）。

- 不对称杂志栅格，衬线大标题，引言竖线
- 按钮：color.primary 填充，圆角使用 radius token；链接使用 color.brand-text
- 使用 templates/tokens/tokens.css 中的变量，不写死颜色值。
