# 海报 · Beta Demo

> 由 DesignBuddy 0.1.2 从 Brand IR 生成（Design System 1.0.0）。

- 衬线大标题，大幅摄影，压图文字需加深色遮罩
- 文字压图时加 color.ink 60% 遮罩，确保对比度
