# 字体 · Alpha Demo

> 由 DesignBuddy 0.1.2 从 Brand IR 生成（Design System 1.0.0）。

| 角色 | 字体 | 回退栈 | 许可 |
|---|---|---|---|
| heading | Source Han Sans SC | PingFang SC, Microsoft YaHei, Noto Sans SC, sans-serif | SIL OFL 1.1 |
| body | Source Han Sans SC | PingFang SC, Microsoft YaHei, Noto Sans SC, sans-serif | SIL OFL 1.1 |

- 标题字重：700；正文字重：400
- 网页字号：display 56px / h1 40px / h2 28px / h3 22px / body 16px / small 14px / caption 12px
- 幻灯片字号：标题 40 / 副标题 28 / 正文 18 / 注释 12
- 中英混排：中英文之间留半角空格；标点使用全角；正文两端对齐时避免孤字
- 本机没有品牌字体时，使用回退栈，并在交付说明中注明。
