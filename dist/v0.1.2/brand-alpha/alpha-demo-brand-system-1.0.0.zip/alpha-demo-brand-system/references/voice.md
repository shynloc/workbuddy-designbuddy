# 语气 · Alpha Demo

> 由 DesignBuddy 0.1.2 从 Brand IR 生成（Design System 1.0.0）。

- 语气：简洁、陈述句、少用感叹号
- 推荐用语：数据、清晰
- 避免用语：颠覆、史上最
- 默认不改写用户的业务内容。
