# 海报 · Alpha Demo

> 由 DesignBuddy 0.1.2 从 Brand IR 生成（Design System 1.0.0）。

- 大标题 + 充足留白，主色色块不超过画面 30%
- 文字压图时加 color.ink 60% 遮罩，确保对比度
