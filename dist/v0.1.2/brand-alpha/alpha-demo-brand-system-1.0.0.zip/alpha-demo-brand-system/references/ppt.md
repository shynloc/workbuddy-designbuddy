# PPT · Alpha Demo

> 由 DesignBuddy 0.1.2 从 Brand IR 生成（Design System 1.0.0）。

- 白底内容页，标题左上，每页一个核心观点；主色仅用于强调
- 16:9；标题字号 40、正文 18；图表主序列用 color.primary，其余用中性灰
