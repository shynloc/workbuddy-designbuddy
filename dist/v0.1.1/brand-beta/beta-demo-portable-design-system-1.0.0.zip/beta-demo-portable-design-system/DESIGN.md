---
name: "Beta Demo"
version: 1.0.0
generated_by: DesignBuddy 0.1.1
schema_version: 1.0.0
colors:
  primary: "#9A3412"
  ink: "#231915"
  paper: "#FFFFFF"
  surface: "#FBF3F1"
  accent: "#139F98"
  on-primary: "#FFFFFF"
  brand-text: "#9A3412"
  success: "#15803D"
  warning: "#B45309"
  error: "#B91C1C"
  info: "#1D4ED8"
typography:
  heading: "Source Han Serif SC"
  body: "Source Han Sans SC"
  heading_weight: 600
spacing:
  base: 8
radius: "2px"
---

# Beta Demo Design System

> 可移植设计系统，适用于 Claude Code、Cursor、Codex、Stitch 等 AI 编码 / 设计工具。唯一事实来源是 `brand-ir.json`，本文件由它生成。

## Overview

把阅读变成可以分享的周末生活方式

性格：温暖、人文、杂志 · 视觉方向：现代编辑

## Colors

| Token | 名称 | 值 | 用途 |
|---|---|---|---|
| `color.primary` | 主色 | `#9A3412` | 标题强调、按钮、图表主序列 |
| `color.ink` | 正文墨色 | `#231915` | 正文与标题文字 |
| `color.paper` | 页面底色 | `#FFFFFF` | 页面与幻灯片背景 |
| `color.surface` | 浅色面 | `#FBF3F1` | 卡片、分区背景 |
| `color.accent` | 强调色 | `#139F98` | 少量高亮与数据标注（非正文文字） |
| `color.on-primary` | 主色上的文字 | `#FFFFFF` | 主色填充上的文字与图标 |
| `color.brand-text` | 品牌色文字 | `#9A3412` | 需要品牌色的文字与链接 |
| `color.success` | 成功 | `#15803D` | 成功状态 |
| `color.warning` | 警告 | `#B45309` | 警告状态 |
| `color.error` | 错误 | `#B91C1C` | 错误状态 |
| `color.info` | 信息 | `#1D4ED8` | 提示信息 |

## Typography

| 角色 | 字体 | 回退 |
|---|---|---|
| heading | Source Han Serif SC | Songti SC, SimSun, Noto Serif SC, serif |
| body | Source Han Sans SC | PingFang SC, Microsoft YaHei, Noto Sans SC, sans-serif |

字号阶梯（px）：display 56, h1 40, h2 28, h3 22, body 16, small 14, caption 12

## Layout

- 间距刻度：8, 16, 24, 32, 48, 64, 96, 128
- 圆角：2px
- 栅格：12 栏，栏间距 24px，最大宽度 1200px

## Imagery & Icons

- 图片：暖色调生活方式摄影，可配手绘质感插画
- 图标：细线图标，少量使用
- 动效：舒缓：250ms 渐显

## Voice

亲切、有叙事感、允许适度修辞

## Do / Don't

- `MUST-COLOR-01` **MUST** 主色固定为 #9A3412（color.primary）
- `MUST-TYPE-01` **MUST** 所有一级标题使用 Source Han Serif SC，字重 600
- `MUST-TYPE-02` **MUST** 正文使用 Source Han Sans SC；不可用时按回退栈替换
- `MUST-A11Y-01` **MUST** 正文文字与背景对比度不低于 4.5:1，大字号不低于 3:1
- `NEVER-LOGO-01` **NEVER** 不得拉伸、旋转、变色 Logo，不得为 Logo 添加阴影或描边
- `NEVER-COLOR-01` **NEVER** 不得使用色板以外的颜色（照片与插画内容除外）
- `AVOID-COLOR-01` **AVOID** 强调色 color.accent 大面积用作背景
- `SHOULD-LAYOUT-01` **SHOULD** 间距使用 spacing 刻度（8 的倍数）
- `NEVER-COLOR-02` **NEVER** 强调色 color.accent 不得用作正文或标题文字
