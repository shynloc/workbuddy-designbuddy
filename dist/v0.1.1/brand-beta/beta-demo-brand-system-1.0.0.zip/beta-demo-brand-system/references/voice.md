# 语气 · Beta Demo

> 由 DesignBuddy 0.1.1 从 Brand IR 生成（Design System 1.0.0）。

- 语气：亲切、有叙事感、允许适度修辞
- 推荐用语：—
- 避免用语：—
- 默认不改写用户的业务内容。
