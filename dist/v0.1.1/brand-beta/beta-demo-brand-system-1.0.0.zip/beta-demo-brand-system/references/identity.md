# Logo 与识别 · Beta Demo

> 由 DesignBuddy 0.1.1 从 Brand IR 生成（Design System 1.0.0）。

- 安全区：Logo 高度的 50%
- 最小尺寸：屏幕 24px / 印刷 8mm
- 允许的背景：color.paper、color.surface、color.primary（反白版）

- `NEVER-LOGO-01` **NEVER** 不得拉伸、旋转、变色 Logo，不得为 Logo 添加阴影或描边
- `NEVER-COLOR-01` **NEVER** 不得使用色板以外的颜色（照片与插画内容除外）
- `NEVER-COLOR-02` **NEVER** 强调色 color.accent 不得用作正文或标题文字
