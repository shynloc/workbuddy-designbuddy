---
name: "Alpha Demo"
version: 1.0.0
generated_by: DesignBuddy 0.1.1
schema_version: 1.0.0
colors:
  primary: "#1F4FD8"
  ink: "#111827"
  paper: "#FFFFFF"
  surface: "#F1F3FB"
  accent: "#B45309"
  on-primary: "#FFFFFF"
  brand-text: "#1F4FD8"
  success: "#15803D"
  warning: "#B45309"
  error: "#B91C1C"
  info: "#1D4ED8"
typography:
  heading: "Source Han Sans SC"
  body: "Source Han Sans SC"
  heading_weight: 700
spacing:
  base: 8
radius: "8px"
---

# Alpha Demo Design System

> 可移植设计系统，适用于 Claude Code、Cursor、Codex、Stitch 等 AI 编码 / 设计工具。唯一事实来源是 `brand-ir.json`，本文件由它生成。

## Overview

让中小企业的数据决策更简单、更可靠

性格：冷静、精确、可靠 · 视觉方向：沉静专业

## Colors

| Token | 名称 | 值 | 用途 |
|---|---|---|---|
| `color.primary` | 主色 | `#1F4FD8` | 标题强调、按钮、图表主序列 |
| `color.ink` | 正文墨色 | `#111827` | 正文与标题文字 |
| `color.paper` | 页面底色 | `#FFFFFF` | 页面与幻灯片背景 |
| `color.surface` | 浅色面 | `#F1F3FB` | 卡片、分区背景 |
| `color.accent` | 强调色 | `#B45309` | 少量高亮与数据标注（非正文文字） |
| `color.on-primary` | 主色上的文字 | `#FFFFFF` | 主色填充上的文字与图标 |
| `color.brand-text` | 品牌色文字 | `#1F4FD8` | 需要品牌色的文字与链接 |
| `color.success` | 成功 | `#15803D` | 成功状态 |
| `color.warning` | 警告 | `#B45309` | 警告状态 |
| `color.error` | 错误 | `#B91C1C` | 错误状态 |
| `color.info` | 信息 | `#1D4ED8` | 提示信息 |

## Typography

| 角色 | 字体 | 回退 |
|---|---|---|
| heading | Source Han Sans SC | PingFang SC, Microsoft YaHei, Noto Sans SC, sans-serif |
| body | Source Han Sans SC | PingFang SC, Microsoft YaHei, Noto Sans SC, sans-serif |

字号阶梯（px）：display 56, h1 40, h2 28, h3 22, body 16, small 14, caption 12

## Layout

- 间距刻度：8, 16, 24, 32, 48, 64, 96, 128
- 圆角：8px
- 栅格：12 栏，栏间距 24px，最大宽度 1200px

## Imagery & Icons

- 图片：自然光、真实办公与人物场景，低饱和，避免夸张特效
- 图标：1.5px 线性图标，圆角端点
- 动效：克制：150–200ms 淡入，不使用弹跳

## Voice

简洁、陈述句、少用感叹号

## Do / Don't

- `MUST-COLOR-01` **MUST** 主色固定为 #1F4FD8（color.primary）
- `MUST-TYPE-01` **MUST** 所有一级标题使用 Source Han Sans SC，字重 700
- `MUST-TYPE-02` **MUST** 正文使用 Source Han Sans SC；不可用时按回退栈替换
- `MUST-A11Y-01` **MUST** 正文文字与背景对比度不低于 4.5:1，大字号不低于 3:1
- `NEVER-LOGO-01` **NEVER** 不得拉伸、旋转、变色 Logo，不得为 Logo 添加阴影或描边
- `NEVER-COLOR-01` **NEVER** 不得使用色板以外的颜色（照片与插画内容除外）
- `AVOID-COLOR-01` **AVOID** 强调色 color.accent 大面积用作背景
- `SHOULD-LAYOUT-01` **SHOULD** 间距使用 spacing 刻度（8 的倍数）
- `NEVER-PHOTO-01` **NEVER** 不得使用带水印的图库图片
