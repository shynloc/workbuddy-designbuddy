# 社交媒体 · Alpha Demo

> 由 DesignBuddy 0.1.1 从 Brand IR 生成（Design System 1.0.0）。

- 小红书 1242×1660、公众号封面 900×383、竖版 1080×1920；Logo 置于安全区内
- 自然光、真实办公与人物场景，低饱和，避免夸张特效
