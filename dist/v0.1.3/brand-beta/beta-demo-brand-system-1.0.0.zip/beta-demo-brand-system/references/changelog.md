# 变更记录 · Beta Demo

> 由 DesignBuddy 0.1.3 从 Brand IR 生成（Design System 1.0.0）。

- 1.0.0：初始版本
