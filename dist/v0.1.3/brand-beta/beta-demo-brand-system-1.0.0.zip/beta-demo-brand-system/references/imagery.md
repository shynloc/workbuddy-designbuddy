# 图片、图标与动效 · Beta Demo

> 由 DesignBuddy 0.1.3 从 Brand IR 生成（Design System 1.0.0）。

- 图片：暖色调生活方式摄影，可配手绘质感插画
- 图标：细线图标，少量使用
- 动效：舒缓：250ms 渐显
- 不复制第三方品牌的 Logo、插画或专有素材。
