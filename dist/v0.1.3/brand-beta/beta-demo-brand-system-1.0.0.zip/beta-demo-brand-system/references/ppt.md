# PPT · Beta Demo

> 由 DesignBuddy 0.1.3 从 Brand IR 生成（Design System 1.0.0）。

- 衬线大标题封面，内容页使用引言与大图
- 16:9；标题字号 40、正文 18；图表主序列用 color.primary，其余用中性灰
