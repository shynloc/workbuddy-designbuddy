# 品牌核心 · Beta Demo

> 由 DesignBuddy 0.1.3 从 Brand IR 生成（Design System 1.0.0）。

| 项 | 内容 |
|---|---|
| 品牌 | Beta Demo |
| 中文名 | 贝塔示例 |
| 英文名 | Beta Demo |
| 别名 | Beta Demo、贝塔示例、Beta、贝塔 |
| 行业 | 独立书店与读书会（虚构） |
| 受众 | 25–40 岁的城市阅读爱好者 |
| 定位 | 把阅读变成可以分享的周末生活方式 |
| 性格 | 温暖、人文、杂志 |
| 价值观 | 分享、好奇 |
| 不想要的感觉 | 冷冰冰、促销感 |
| 视觉方向 | 现代编辑（Editorial Modern） |

## 关键规则

- `MUST-COLOR-01` **MUST** 主色固定为 #9A3412（color.primary）
- `MUST-TYPE-01` **MUST** 所有一级标题使用 Source Han Serif SC，字重 600
- `MUST-TYPE-02` **MUST** 正文使用 Source Han Sans SC；不可用时按回退栈替换
- `MUST-A11Y-01` **MUST** 正文文字与背景对比度不低于 4.5:1，大字号不低于 3:1
- `NEVER-LOGO-01` **NEVER** 不得拉伸、旋转、变色 Logo，不得为 Logo 添加阴影或描边
- `NEVER-COLOR-01` **NEVER** 不得使用色板以外的颜色（照片与插画内容除外）
- `NEVER-COLOR-02` **NEVER** 强调色 color.accent 不得用作正文或标题文字
