# 网页 · Alpha Demo

> 由 DesignBuddy 0.1.3 从 Brand IR 生成（Design System 1.0.0）。

- 12 栏栅格，充足留白，左对齐
- 按钮：color.primary 填充，圆角使用 radius token；链接使用 color.brand-text
- 使用 templates/tokens/tokens.css 中的变量，不写死颜色值。
