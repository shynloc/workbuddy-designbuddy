# 无障碍 · Beta Demo

> 由 DesignBuddy 0.1.0 从 Brand IR 生成（Design System 1.0.0）。

目标：WCAG 2.x AA。正文 ≥ 4.5:1，大字号与非文字 UI ≥ 3:1。

| 组合 | 颜色 | 对比度 | 结果 |
|---|---|---|---|
| body-text/page | `#231915` on `#FFFFFF` | 17.19:1 | PASS |
| body-text/surface | `#231915` on `#FBF3F1` | 15.71:1 | PASS |
| on-primary/primary | `#FFFFFF` on `#9A3412` | 7.31:1 | PASS |
| brand-text/page | `#9A3412` on `#FFFFFF` | 7.31:1 | PASS |
| primary-as-text/page | `#9A3412` on `#FFFFFF` | 7.31:1 | PASS |
| accent-ui/page | `#139F98` on `#FFFFFF` | 3.26:1 | PASS |
| success/page | `#15803D` on `#FFFFFF` | 5.02:1 | PASS |
| warning/page | `#B45309` on `#FFFFFF` | 5.02:1 | PASS |
| error/page | `#B91C1C` on `#FFFFFF` | 6.47:1 | PASS |
| info/page | `#1D4ED8` on `#FFFFFF` | 6.7:1 | PASS |
