# 图标 · Beta Demo

> 由 DesignBuddy 0.1.0 从 Brand IR 生成（Design System 1.0.0）。

- 细线图标，少量使用
- 图标颜色只使用 color.ink、color.primary、color.on-primary。
