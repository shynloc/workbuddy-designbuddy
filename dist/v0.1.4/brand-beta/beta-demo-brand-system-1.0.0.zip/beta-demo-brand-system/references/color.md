# 颜色 · Beta Demo

> 由 DesignBuddy 0.1.4 从 Brand IR 生成（Design System 1.0.0）。

| token | 名称 | 值 | 用途 |
|---|---|---|---|
| `color.primary` | 主色 | `#9A3412` | 标题强调、按钮、图表主序列 |
| `color.ink` | 正文墨色 | `#231915` | 正文与标题文字 |
| `color.paper` | 页面底色 | `#FFFFFF` | 页面与幻灯片背景 |
| `color.surface` | 浅色面 | `#FBF3F1` | 卡片、分区背景 |
| `color.accent` | 强调色 | `#139F98` | 少量高亮与数据标注（非正文文字） |
| `color.on-primary` | 主色上的文字 | `#FFFFFF` | 主色填充上的文字与图标 |
| `color.brand-text` | 品牌色文字 | `#9A3412` | 需要品牌色的文字与链接 |
| `color.success` | 成功 | `#15803D` | 成功状态 |
| `color.warning` | 警告 | `#B45309` | 警告状态 |
| `color.error` | 错误 | `#B91C1C` | 错误状态 |
| `color.info` | 信息 | `#1D4ED8` | 提示信息 |

只使用上表中的颜色（NEVER-COLOR-01）。CSS 变量名 = token 中的 `.` 换成 `-`，例如 `var(--color-primary)`。
