# Word / PDF · Beta Demo

> 由 DesignBuddy 0.1.4 从 Brand IR 生成（Design System 1.0.0）。

- Word / PDF：标题使用 heading 字体，正文 body 字体 11–12pt，行距 1.5
- 页眉放置 Logo（遵守安全区），页脚放页码
