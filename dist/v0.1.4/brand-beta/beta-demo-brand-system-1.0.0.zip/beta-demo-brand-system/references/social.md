# 社交媒体 · Beta Demo

> 由 DesignBuddy 0.1.4 从 Brand IR 生成（Design System 1.0.0）。

- 小红书 1242×1660、公众号封面 900×383、竖版 1080×1920；Logo 置于安全区内
- 暖色调生活方式摄影，可配手绘质感插画
